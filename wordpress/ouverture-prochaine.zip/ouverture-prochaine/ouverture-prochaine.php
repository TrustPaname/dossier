<?php
/**
 * Plugin Name: Ouverture prochaine (compte à rebours)
 * Description: Affiche aux visiteurs une page « Ouverture le … » avec un compte à rebours, quel que soit le thème actif. Réglages : Apparence → Personnaliser → Ouverture prochaine. Les administrateurs connectés voient le vrai site ; ajoutez ?ouverture=1 à l'adresse pour voir la page d'attente.
 * Version: 1.2.0
 * Author: Motor Corp
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Détecte la société d'après le thème actif ; sinon, nom du site. */
function ouverture_prochaine_config() {
	$theme = get_template();
	$uri   = get_template_directory_uri();
	$dir   = get_template_directory();
	$sites = array(
		'motor-consulting' => array( 'nom' => 'Motor Consulting', 'logo' => 'assets/img/logo-motor-consulting-600.png', 'couleur' => '#0a8cff', 'police' => array( 'Outfit', 'assets/fonts/outfit-300-800-latin.woff2' ) ),
		'motor-corp'       => array( 'nom' => 'Motor Corp',       'logo' => 'assets/img/logo-motor-corp.png',            'couleur' => '#f04a00', 'police' => array( 'Archivo', 'assets/fonts/archivo-latin.woff2' ) ),
		'motors-studio'    => array( 'nom' => 'Motors Studio',    'logo' => 'assets/img/logo-motors-studio.png',         'couleur' => '#e3231a', 'police' => array( 'Outfit', 'assets/fonts/outfit-300-800-latin.woff2' ) ),
		'ms-motor-studio'  => array( 'nom' => 'Motors Studio',    'logo' => 'assets/img/logo-motors-studio.png',         'couleur' => '#e3231a', 'police' => array() ),
	);
	$c = isset( $sites[ $theme ] ) ? $sites[ $theme ] : array( 'nom' => get_bloginfo( 'name' ), 'logo' => '', 'couleur' => '#0a8cff', 'police' => array() );
	$c['prefix']   = 'ouv_';
	$c['logo_url'] = ( $c['logo'] && file_exists( $dir . '/' . $c['logo'] ) ) ? $uri . '/' . $c['logo'] : '';
	if ( ! empty( $c['police'][1] ) ) {
		$c['police'][1] = file_exists( $dir . '/' . $c['police'][1] ) ? $uri . '/' . $c['police'][1] : '';
	}
	return $c;
}


$GLOBALS['ouverture_prochaine_cfg'] = ouverture_prochaine_config();

function ouverture_prochaine_cfg( $k, $d = '' ) {
	$c = $GLOBALS['ouverture_prochaine_cfg'];
	return isset( $c[ $k ] ) ? $c[ $k ] : $d;
}

function ouverture_prochaine_mod( $k, $d = '' ) {
	return get_theme_mod( ouverture_prochaine_cfg( 'prefix', 'motor_' ) . 'ouverture_' . $k, $d );
}

/** Date-heure d'ouverture (objet DateTime dans le fuseau du site) ou null. */
function ouverture_prochaine_date() {
	$date  = trim( (string) ouverture_prochaine_mod( 'date', '2026-11-05' ) );
	$heure = trim( (string) ouverture_prochaine_mod( 'heure', '09:00' ) );
	try {
		return new DateTime( $date . ' ' . ( $heure ? $heure : '09:00' ), wp_timezone() );
	} catch ( Exception $e ) {
		return null;
	}
}

/** La page d'attente doit-elle s'afficher pour ce visiteur ? */
function ouverture_prochaine_active() {
	if ( ! ouverture_prochaine_mod( 'active', 1 ) ) {
		return false;
	}
	// ?ouverture=1 dans l'adresse : force l'affichage de la page d'attente, même connecté (pour vérifier).
	// ?ouverture=0 : affiche le vrai site sans être connecté (pour vérifier le site avant l'ouverture).
	$force = isset( $_GET['ouverture'] ) && '1' === $_GET['ouverture']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( isset( $_GET['ouverture'] ) && '0' === $_GET['ouverture'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! headers_sent() ) {
			setcookie( 'mc_ouverture', '0', time() + DAY_IN_SECONDS, '/' );
		}
		return false;
	}
	// Le visiteur a cliqué sur « Accéder au site » : il navigue librement pendant 24 h.
	if ( ! $force && isset( $_COOKIE['mc_ouverture'] ) && '0' === $_COOKIE['mc_ouverture'] ) {
		return false;
	}
	if ( ! $force && is_user_logged_in() && current_user_can( 'edit_theme_options' ) ) {
		return false; // l'administrateur continue de voir et régler le vrai site
	}
	if ( is_customize_preview() ) {
		return false;
	}
	$d = ouverture_prochaine_date();
	if ( ! $d ) {
		return false;
	}
	return $d->getTimestamp() > current_time( 'timestamp', true );
}

add_action( 'customize_register', function ( $wp_customize ) {
	$p = ouverture_prochaine_cfg( 'prefix', 'motor_' );
	$wp_customize->add_section( $p . 'ouverture', array(
		'title'       => 'Ouverture prochaine (compte à rebours)',
		'priority'    => 10,
		'description' => 'Tant que la case est cochée et que la date n\'est pas passée, les visiteurs voient une page « Ouverture le … » avec un compte à rebours. Vous, connecté, voyez le vrai site.',
	) );
	$fields = array(
		'active'  => array( 'Afficher la page d\'attente aux visiteurs', 'checkbox', 1 ),
		'mode'    => array( 'Affichage', 'select', 'overlay' ),
		'date'    => array( 'Date d\'ouverture (AAAA-MM-JJ)', 'text', '2026-11-05' ),
		'heure'   => array( 'Heure d\'ouverture (HH:MM)', 'text', '09:00' ),
		'titre'   => array( 'Texte au-dessus de la date', 'text', 'Ouverture le' ),
		'message' => array( 'Phrase sous le compte à rebours (facultatif)', 'text', '' ),
	);
	foreach ( $fields as $k => $f ) {
		$wp_customize->add_setting( $p . 'ouverture_' . $k, array(
			'default'           => $f[2],
			'sanitize_callback' => 'checkbox' === $f[1] ? 'absint' : 'sanitize_text_field',
		) );
		$ctl = array(
			'label'   => $f[0],
			'section' => $p . 'ouverture',
			'type'    => $f[1],
		);
		if ( 'mode' === $k ) {
			$ctl['choices']     = array(
				'overlay' => 'Par-dessus le site (recommandé : Google lit le vrai site)',
				'page'    => 'Page seule (le site reste invisible, non référencé)',
			);
			$ctl['description'] = 'Dans les deux cas le visiteur ne voit que le compte à rebours.';
		}
		$wp_customize->add_control( $p . 'ouverture_' . $k, $ctl );
	}
} );

/** Bandeau de rappel dans l'administration tant que la page d'attente est active. */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'edit_theme_options' ) || ! ouverture_prochaine_mod( 'active', 1 ) ) {
		return;
	}
	$d = ouverture_prochaine_date();
	if ( ! $d || $d->getTimestamp() <= current_time( 'timestamp', true ) ) {
		return;
	}
	echo '<div class="notice notice-warning"><p><strong>' . esc_html( ouverture_prochaine_cfg( 'nom', 'Site' ) ) . ' :</strong> les visiteurs voient la page « Ouverture le ' . esc_html( wp_date( 'j F Y', $d->getTimestamp() ) ) . ' » avec le compte à rebours. Vous voyez le vrai site parce que vous êtes connecté : pour la voir vous-même, <a href="' . esc_url( home_url( '/?ouverture=1' ) ) . '" target="_blank">ouvrez cette page</a>. Pour ouvrir le site au public : Apparence → Personnaliser → Ouverture prochaine → décochez la case.</p></div>';
} );

/** Mode « page » : remplace toutes les pages publiques. Mode « par-dessus » : voir wp_footer plus bas. */
add_action( 'template_redirect', function () {
	if ( ! ouverture_prochaine_active() || 'page' !== ouverture_prochaine_mod( 'mode', 'overlay' ) ) {
		return;
	}
	if ( is_feed() || is_robots() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return;
	}
	status_header( 200 );
	nocache_headers();
	header( 'Content-Type: text/html; charset=utf-8' );
	ouverture_prochaine_render( false );
	exit;
} );

/** Mode « par-dessus » : le vrai site est servi (Google le lit), le compte à rebours le recouvre pour le visiteur. */
add_action( 'wp_footer', function () {
	if ( ! ouverture_prochaine_active() || 'page' === ouverture_prochaine_mod( 'mode', 'overlay' ) ) {
		return;
	}
	ouverture_prochaine_render( true );
}, 99 );
add_action( 'wp_head', function () {
	if ( ! ouverture_prochaine_active() || 'page' === ouverture_prochaine_mod( 'mode', 'overlay' ) ) {
		return;
	}
	echo '<style id="o-lock">html.o-lock,html.o-lock body{overflow:hidden!important;height:100%}</style>' . "\n";
}, 99 );

function ouverture_prochaine_render( $overlay = false ) {
	$nom     = ouverture_prochaine_cfg( 'nom', get_bloginfo( 'name' ) );
	$couleur = ouverture_prochaine_cfg( 'couleur', '#0a8cff' );
	$logo    = ouverture_prochaine_cfg( 'logo_url' );
	$police  = ouverture_prochaine_cfg( 'police' );
	$d       = ouverture_prochaine_date();
	$iso     = $d->format( 'c' );
	$jour    = wp_date( 'j F Y', $d->getTimestamp() );
	$titre   = ouverture_prochaine_mod( 'titre', 'Ouverture le' );
	$message = ouverture_prochaine_mod( 'message', '' );
	$font_face = '';
	$font_name = 'system-ui, -apple-system, "Segoe UI", sans-serif';
	$r = $overlay ? '.o-ouv' : 'body'; // racine des styles
	$o = $overlay ? '.o-ouv ' : '';   // préfixe des classes internes
	if ( is_array( $police ) && ! empty( $police[0] ) ) {
		$font_name = '"' . $police[0] . '", ' . $font_name;
		if ( ! empty( $police[1] ) ) {
			$font_face = '@font-face{font-family:"' . $police[0] . '";font-weight:300 800;font-display:swap;src:url("' . esc_url( $police[1] ) . '") format("woff2")}';
		}
	}
	if ( ! $overlay ) :
	?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, follow">
<title><?php echo esc_html( $nom ); ?> — <?php echo esc_html( $titre . ' ' . $jour ); ?></title>
<?php if ( function_exists( 'wp_site_icon' ) ) { wp_site_icon(); } ?>
<?php else : ?>
<div class="o-ouv" id="o-ouv" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr( $nom . ' — ' . $titre . ' ' . $jour ); ?>">
<?php endif; ?>
<style>
<?php echo $font_face; // phpcs:ignore WordPress.Security.EscapeOutput -- URL échappée ci-dessus ?>
<?php if ( ! $overlay ) : ?>*{box-sizing:border-box;margin:0}html,body{height:100%}<?php endif; ?>
<?php echo $r; ?> *{box-sizing:border-box;margin:0}
<?php echo $r; ?>{font-family:<?php echo $font_name; // phpcs:ignore WordPress.Security.EscapeOutput ?>;background:#0b0c10;color:#fff;display:grid;place-items:center;text-align:center;padding:32px 20px;overflow:hidden;position:relative;-webkit-font-smoothing:antialiased;<?php if ( $overlay ) : ?>position:fixed;inset:0;z-index:2147483647;overflow:auto;min-height:100%;height:auto<?php endif; ?>}
<?php echo $r; ?>::before{content:"";position:fixed;inset:0;background:
  radial-gradient(60% 50% at 50% 35%,<?php echo esc_attr( $couleur ); ?>33,transparent 65%),
  radial-gradient(40% 35% at 85% 90%,<?php echo esc_attr( $couleur ); ?>22,transparent 60%),
  linear-gradient(180deg,#15171c 0%,#0b0c10 70%);z-index:-2}
<?php echo $r; ?>::after{content:"";position:fixed;inset:0;background-image:linear-gradient(rgba(255,255,255,.035) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.035) 1px,transparent 1px);background-size:56px 56px;mask-image:radial-gradient(70% 70% at 50% 50%,#000 20%,transparent 100%);-webkit-mask-image:radial-gradient(70% 70% at 50% 50%,#000 20%,transparent 100%);z-index:-1}
<?php echo $o; ?>.o{display:grid;gap:26px;justify-items:center;max-width:860px;animation:in .9s ease both}
@keyframes in{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
<?php echo $o; ?>.o__logo{width:min(300px,64vw);height:auto;filter:drop-shadow(0 20px 40px rgba(0,0,0,.6))}
<?php echo $o; ?>.o__nom{font-size:clamp(1.1rem,2.4vw,1.5rem);font-weight:600;letter-spacing:.32em;text-transform:uppercase;color:rgba(255,255,255,.72)}
<?php echo $o; ?>.o__kicker{display:inline-flex;align-items:center;gap:.7em;padding:9px 18px;border-radius:999px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.05);font-size:.72rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase}
<?php echo $o; ?>.o__kicker::before{content:"";width:7px;height:7px;border-radius:50%;background:<?php echo esc_attr( $couleur ); ?>;box-shadow:0 0 12px <?php echo esc_attr( $couleur ); ?>}
<?php echo $o; ?>.o__date{font-size:clamp(2rem,6.5vw,4.4rem);font-weight:800;line-height:1.05;letter-spacing:-.02em;color:#fff;font-family:inherit}
<?php echo $o; ?>.o__date em{font-style:italic;color:<?php echo esc_attr( $couleur ); ?>}
<?php echo $o; ?>.o__cd{display:flex;flex-wrap:wrap;justify-content:center;gap:12px;margin-top:6px}
<?php echo $o; ?>.o__cell{min-width:clamp(74px,16vw,118px);padding:16px 10px 12px;border-radius:18px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);backdrop-filter:blur(8px)}
<?php echo $o; ?>.o__cell b{display:block;font-size:clamp(1.9rem,5.2vw,3.2rem);font-weight:800;line-height:1;font-variant-numeric:tabular-nums;color:#fff}
<?php echo $o; ?>.o__cell span{display:block;margin-top:8px;font-size:.64rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:rgba(255,255,255,.55)}
<?php echo $o; ?>.o__msg{color:rgba(255,255,255,.7);font-size:1rem;max-width:520px;line-height:1.6}
<?php echo $o; ?>.o__foot{margin-top:10px;font-size:.78rem;color:rgba(255,255,255,.4);letter-spacing:.06em}
<?php echo $o; ?>.o__open{display:none}
<?php echo $o; ?>.is-open .o__cd,<?php echo $o; ?>.is-open .o__kicker{display:none}
<?php echo $o; ?>.o__enter{display:inline-flex;align-items:center;gap:.5em;margin-top:4px;padding:13px 26px;border-radius:999px;border:1px solid rgba(255,255,255,.35);background:rgba(255,255,255,.06);color:#fff;font-weight:600;font-size:.95rem;text-decoration:none;letter-spacing:.02em;transition:background .25s,border-color .25s}
<?php echo $o; ?>.o__enter:hover{background:<?php echo esc_attr( $couleur ); ?>;border-color:<?php echo esc_attr( $couleur ); ?>}
<?php echo $o; ?>.is-open .o__enter{display:none}
<?php echo $o; ?>.is-open .o__open{display:inline-block;margin-top:8px;padding:14px 26px;border-radius:999px;background:<?php echo esc_attr( $couleur ); ?>;color:#fff;font-weight:700;text-decoration:none}
@media (prefers-reduced-motion:reduce){<?php echo $o; ?>.o{animation:none}}
<?php if ( $overlay ) : ?>.o-ouv{color:#fff}.o-ouv h1{font-family:inherit}<?php endif; ?>
</style>
<?php if ( ! $overlay ) : ?>
</head>
<body>
<?php endif; ?>
<main class="o" id="o" data-date="<?php echo esc_attr( $iso ); ?>">
	<?php if ( $logo ) : ?>
	<img class="o__logo" src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( $nom ); ?>">
	<?php else : ?>
	<p class="o__nom"><?php echo esc_html( $nom ); ?></p>
	<?php endif; ?>
	<p class="o__kicker"><?php echo esc_html( $nom ); ?> · Site en préparation</p>
	<h1 class="o__date"><?php echo esc_html( $titre ); ?> <em><?php echo esc_html( $jour ); ?></em></h1>
	<div class="o__cd" aria-live="polite" aria-label="Compte à rebours">
		<div class="o__cell"><b id="cd-j">—</b><span>jours</span></div>
		<div class="o__cell"><b id="cd-h">—</b><span>heures</span></div>
		<div class="o__cell"><b id="cd-m">—</b><span>minutes</span></div>
		<div class="o__cell"><b id="cd-s">—</b><span>secondes</span></div>
	</div>
	<?php if ( $message ) : ?><p class="o__msg"><?php echo esc_html( $message ); ?></p><?php endif; ?>
	<a class="o__open" href="<?php echo esc_url( home_url( '/' ) ); ?>">Découvrir le site</a>
	<a class="o__enter" id="o-enter" href="<?php echo esc_url( home_url( '/?ouverture=0' ) ); ?>">Accéder au site <span aria-hidden="true">→</span></a>
	<p class="o__foot">© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( $nom ); ?></p>
</main>
<script>
(function(){
  var el=document.getElementById('o'),cible=new Date(el.getAttribute('data-date')).getTime();
  <?php if ( $overlay ) : ?>document.documentElement.classList.add('o-lock');
  var entrer=document.getElementById('o-enter');
  if(entrer){entrer.addEventListener('click',function(e){e.preventDefault();document.cookie='mc_ouverture=0; path=/; max-age=86400; SameSite=Lax';var w=document.getElementById('o-ouv');if(w){w.parentNode.removeChild(w);}document.documentElement.classList.remove('o-lock');});}<?php endif; ?>
  var j=document.getElementById('cd-j'),h=document.getElementById('cd-h'),m=document.getElementById('cd-m'),s=document.getElementById('cd-s');
  var p=function(n){return n<10?'0'+n:String(n);};
  function maj(){
    var d=cible-Date.now();
    if(d<=0){el.classList.add('is-open');<?php if ( $overlay ) : ?>var w=document.getElementById('o-ouv');if(w){w.parentNode.removeChild(w);}document.documentElement.classList.remove('o-lock');<?php endif; ?>return;}
    var sec=Math.floor(d/1000);
    j.textContent=Math.floor(sec/86400);h.textContent=p(Math.floor(sec%86400/3600));m.textContent=p(Math.floor(sec%3600/60));s.textContent=p(sec%60);
    setTimeout(maj,1000-(Date.now()%1000));
  }
  maj();
})();
</script>
<?php if ( $overlay ) : ?>
</div>
<?php else : ?>
</body>
</html>
<?php endif; ?>
	<?php
}
