<?php
/**
 * Page « Prendre rendez-vous » (/rdv/) — générée par wordpress/build.py à partir de motors-studio/rdv.html.
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Prendre rendez-vous — Motors Studio, carrosserie et mécanique à Chartres</title>
<meta name="description" content="Réservez votre rendez-vous chez Motors Studio à Mainvilliers : carrosserie, mécanique, pneus, pare-brise. Offres de lancement pour les 20 premiers rendez-vous. Rappel sous 24h.">
<meta name="author" content="Motors Studio">
<meta name="robots" content="noindex, follow">
<link rel="canonical" href="https://www.motors-studio.fr/rdv/">

<meta property="og:type" content="website">
<meta property="og:locale" content="fr_FR">
<meta property="og:site_name" content="Motors Studio">
<meta property="og:title" content="Motors Studio — Carrosserie, mécanique, pneus et pare-brise à Chartres">
<meta property="og:description" content="Garage toutes marques à Mainvilliers, aux portes de Chartres : carrosserie, peinture, débosselage, mécanique, pneus, pare-brise. Devis gratuit sous 24h, prise en charge assurance, véhicule de courtoisie.">
<meta property="og:url" content="https://www.motors-studio.fr/rdv/">
<meta property="og:image" content="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/og-cover.png">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#ffffff">

<link rel="icon" href="<?php echo esc_url( get_template_directory_uri() ); ?>/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="<?php echo esc_url( get_template_directory_uri() ); ?>/favicon.svg">

<script>document.documentElement.classList.add("js");</script>

<?php wp_head(); ?>
</head>
<body class="landing">
<a class="skip-link" href="#main">Aller au contenu principal</a>
<header class="header" id="header">
  <div class="container header__inner">
    <a class="logo logo--compact" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Motors Studio, retour à l'accueil">
      <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/logo-motors-studio-light.png" alt="Motors Studio" width="300" height="151">
    </a>
    <nav class="nav legal__topnav" aria-label="Contact">
      <div class="nav__cta">
        <a class="nav__tel" href="tel:<?php echo esc_attr( motor_opt( 'phone_e164' ) ); ?>" data-conversion="appel"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 3.5h3l1.5 4-2 1.5a12 12 0 0 0 6 6l1.5-2 4 1.5v3c0 .9-.7 1.6-1.6 1.5C10.6 19.9 4.1 13.4 3.5 5.1A1.5 1.5 0 0 1 5 3.5h1.5Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg> <?php echo esc_html( motor_opt( 'phone_display' ) ); ?></a>
        <a class="btn btn--primary" href="#quick-form">Prendre rendez-vous</a>
      </div>
    </nav>
  </div>
</header>

<main id="main">
<section class="hero hero--landing" id="accueil">
  <div class="hero__bg" aria-hidden="true"></div>
  <div class="container hero__inner">
    <div>
      <span class="hero__badge">Ouverture le 5 novembre 2026 · Mainvilliers, près de Chartres</span>
      <h1>Carrosserie, mécanique, pneus, pare-brise : <span class="accent">réservez votre rendez-vous</span></h1>
      <p class="hero__sub2">Garage et carrosserie toutes marques à Mainvilliers. Remplissez le formulaire, <strong>nous vous rappelons sous 24h</strong> pour fixer la date. Devis gratuit, prise en charge assurance, véhicule de courtoisie.</p>
      <div class="offres" aria-label="Offres de lancement">
        <p class="offres__titre">Offres de lancement · réservées aux 20 premiers rendez-vous</p>
        <ul class="offres__grid">
          <li><b>-50 %</b><span>Carrosserie · Peinture · Redressage</span><small>hors assurance</small></li>
          <li><b>-40 %</b><span>Pneumatiques</span><small>montage, équilibrage, remplacement</small></li>
          <li><b>Franchise offerte</b><span>Pare-brise</span><small>+ balais d'essuie-glace offerts</small></li>
        </ul>
        <p class="offres__note">Voir conditions à l'atelier.</p>
      </div>
      <ul class="hero__proof">
        <li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5 4 5.4v6c0 5 3.4 9.3 8 10.9 4.6-1.6 8-5.9 8-10.9v-6l-8-2.9Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="m8.6 12 2.4 2.4 4.6-4.6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg> <strong>Agréé</strong> toutes assurances</li>
        <li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 17.5v-3.4l2-4.4c.35-.8 1-1.2 1.9-1.2h9.2c.9 0 1.55.4 1.9 1.2l2 4.4v3.4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M3.5 17.5h17M5.6 14.1h2.6M15.8 14.1h2.6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg> <strong>Véhicule</strong> de courtoisie</li>
        <li><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="m8.5 12.3 2.4 2.4 4.8-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg> <strong>Garantie</strong> sur chaque intervention</li>
      </ul>
    </div>

    <form class="search" id="quick-form" aria-label="Demande de rendez-vous" novalidate>
      <div class="search__head">
        <p class="search__title"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3.5h7l4 4V20a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4.5a1 1 0 0 1 1-1Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M9 12h6M9 15.5h6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg> Demande de rendez-vous</p>
        <span class="search__count">Rappel sous 24h</span>
      </div>
      <p class="hp" aria-hidden="true"><label>Ne pas remplir <input type="text" name="website" tabindex="-1" autocomplete="off"></label></p>
      <input type="hidden" name="sujet" value="Demande de rendez-vous">
      <div class="search__grid">
        <div class="search__field"><label for="q-nom">Nom</label>
          <input type="text" id="q-nom" name="nom" autocomplete="family-name" required><p class="field__error" data-error-for="q-nom"></p></div>
        <div class="search__field"><label for="q-prenom">Prénom</label>
          <input type="text" id="q-prenom" name="prenom" autocomplete="given-name" required><p class="field__error" data-error-for="q-prenom"></p></div>
        <div class="search__field"><label for="q-email">E-mail</label>
          <input type="email" id="q-email" name="email" autocomplete="email" placeholder="vous@exemple.fr" required><p class="field__error" data-error-for="q-email"></p></div>
        <div class="search__field"><label for="q-tel">Téléphone</label>
          <input type="tel" id="q-tel" name="telephone" placeholder="06 00 00 00 00" required><p class="field__error" data-error-for="q-tel"></p></div>
        <div class="search__field"><label for="q-prestation">Prestation</label>
          <select id="q-prestation" name="prestation"><option value="">Choisir…</option><option>Carrosserie / Peinture / Débosselage</option><option>Entretien / Révision / Freins</option><option>Pneus</option><option>Pare-brise</option><option>Diagnostic / panne</option><option>Plusieurs prestations</option><option>Autre</option></select></div>
        <div class="search__field"><label for="q-immat">Immatriculation</label>
          <input type="text" id="q-immat" name="immatriculation" placeholder="AB-123-CD" autocapitalize="characters" spellcheck="false" required><p class="field__error" data-error-for="q-immat"></p></div>
        <div class="search__field"><label for="q-sinistre">Sinistre assurance ?</label>
          <select id="q-sinistre" name="assurance"><option>Non</option><option>Oui, dossier assurance</option><option>Je ne sais pas</option></select></div>
      </div>
      <button class="search__submit" type="submit"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 11.5 20 4l-4 16-4.5-6.5L3.5 11.5Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg> Être rappelé pour un RDV</button>
      <div class="search__pop">
        <span>Demandes fréquentes · plusieurs choix possibles</span>
        <div class="search__chips" id="q-chips">
          <button type="button" data-prestation="Carrosserie / Peinture / Débosselage" aria-pressed="false">Rayure</button><button type="button" data-prestation="Carrosserie / Peinture / Débosselage" aria-pressed="false">Pare-chocs</button><button type="button" data-prestation="Carrosserie / Peinture / Débosselage" aria-pressed="false">Portière</button><button type="button" data-prestation="Carrosserie / Peinture / Débosselage" aria-pressed="false">Aile</button><button type="button" data-prestation="Carrosserie / Peinture / Débosselage" aria-pressed="false">Capot</button><button type="button" data-prestation="Carrosserie / Peinture / Débosselage" aria-pressed="false">Grêle</button><button type="button" data-prestation="Carrosserie / Peinture / Débosselage" aria-pressed="false">Peinture complète</button><button type="button" data-prestation="Entretien / Révision / Freins" aria-pressed="false">Vidange</button><button type="button" data-prestation="Entretien / Révision / Freins" aria-pressed="false">Révision</button><button type="button" data-prestation="Entretien / Révision / Freins" aria-pressed="false">Disques</button><button type="button" data-prestation="Entretien / Révision / Freins" aria-pressed="false">Plaquettes</button><button type="button" data-prestation="Entretien / Révision / Freins" aria-pressed="false">Distribution</button><button type="button" data-prestation="Entretien / Révision / Freins" aria-pressed="false">Climatisation</button><button type="button" data-prestation="Entretien / Révision / Freins" aria-pressed="false">Contrôle technique</button><button type="button" data-prestation="Pneus" aria-pressed="false">Pneus été</button><button type="button" data-prestation="Pneus" aria-pressed="false">Pneus hiver</button><button type="button" data-prestation="Pneus" aria-pressed="false">Équilibrage</button><button type="button" data-prestation="Pneus" aria-pressed="false">Géométrie</button><button type="button" data-prestation="Pare-brise" aria-pressed="false">Impact pare-brise</button><button type="button" data-prestation="Pare-brise" aria-pressed="false">Remplacement pare-brise</button><button type="button" data-prestation="Pare-brise" aria-pressed="false">Vitre latérale</button>
        </div>
        <input type="hidden" name="demandes" id="q-demandes" value="">
      </div>
      <p class="form__status" role="status" aria-live="polite" id="quick-status"></p>
    </form>
  </div>
</section>

<section class="section landing__infos">
  <div class="container">
    <ul class="reassure__grid reassure__grid--landing">
      <li class="reassure__item"><strong>Où ?</strong><span><?php echo esc_html( motor_opt( 'address' ) ); ?>, aux portes de Chartres</span></li>
      <li class="reassure__item"><strong>Quand ?</strong><span>Du lundi au samedi, 9h–12h et 13h30–19h, dès le 5 novembre 2026</span></li>
      <li class="reassure__item"><strong>Par téléphone</strong><span><a href="tel:<?php echo esc_attr( motor_opt( 'phone_e164' ) ); ?>" data-conversion="appel"><?php echo esc_html( motor_opt( 'phone_display' ) ); ?></a> · ou photos par <a href="https://wa.me/<?php echo esc_attr( motor_opt( 'whatsapp' ) ); ?>?text=Bonjour%2C%20je%20souhaite%20prendre%20rendez-vous." target="_blank" rel="noopener" data-conversion="whatsapp">WhatsApp</a></span></li>
    </ul>
  </div>
</section>
</main>

<footer class="footer footer--legal">
  <div class="container footer__bottom">
    <p>© 2026 Motors Studio · Garage et carrosserie à Mainvilliers</p>
    <ul class="footer__legal"><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Site complet</a></li><li><a href="<?php echo esc_url( home_url( '/mentions-legales/' ) ); ?>">Mentions légales</a></li><li><a href="<?php echo esc_url( home_url( '/confidentialite/' ) ); ?>">Confidentialité</a></li></ul>
  </div>
</footer>

<!-- Barre d'action mobile -->
<div class="mobile-bar" aria-label="Contact rapide">
  <a class="mobile-bar__btn" href="tel:<?php echo esc_attr( motor_opt( 'phone_e164' ) ); ?>" data-conversion="appel"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 3.5h3l1.5 4-2 1.5a12 12 0 0 0 6 6l1.5-2 4 1.5v3c0 .9-.7 1.6-1.6 1.5C10.6 19.9 4.1 13.4 3.5 5.1A1.5 1.5 0 0 1 5 3.5h1.5Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg> Appeler</a>
  <a class="mobile-bar__btn mobile-bar__btn--wa" href="https://wa.me/<?php echo esc_attr( motor_opt( 'whatsapp' ) ); ?>?text=Bonjour%2C%20je%20souhaite%20prendre%20rendez-vous." target="_blank" rel="noopener" data-conversion="whatsapp"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.6L3 21l4.5-1.2A9 9 0 1 0 12 3Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg> WhatsApp</a>
  <a class="mobile-bar__btn mobile-bar__btn--cta" href="#quick-form">Rendez-vous</a>
</div>

<?php wp_footer(); ?>
</body>
</html>
